/* 
 * This have been a lot of work to do.  
 * But i'm not the MAFIAA, IFPI, an angry software development company or anything like that, trying to stop progress.
 * If you can use the below code to ANYTHING, then that would make me glad.
 * So plz. read my code, copy my code, use my code, destroy it beyond recognition, i don't care.
 * As long as you tell me what you did with it 
 */
// Global variables. 
var pushSyncNoteID = false;	 
var pushSyncNoteTimeout = false;
var textAreaKeyUpSyncTimer = false;
var localSupport = Modernizr.localstorage;
var online = true;

// Initializing. 
initTodoApp();
// The bindings. 
$(document).ready(function () {
	// Maybe theres something to do from earlyer, maybe not. 
	// But anyway, the syncing is set up as the first thing. 
	sendLocalNoteSync();
	
	/*$('#test').click(function() {
		sendLocalNoteSync();	
	});*/
	
    $('.add-new-note').live('click', function() {
		// Lazy sync, make change now, send to server later. 
		var tmpTime = new Date().getTime().toString(); // If i didn't add the last toString, i would just have saved the method, not the actual current time. 
		tmpTime = 'TemperaryNoteId' + tmpTime.toString();
		insertNote(tmpTime, '', 'false', true);
		saveLocalNotes();
		saveLocalNoteSync('added', tmpTime, false);
		return false;
	});
	$('.save').live('click', function() {
		saveLocalNotes(); // Saving notes whenever there can be a change to the notes. 
		saveNote($(this).parents('li'), true);
	});
	// Doing more damager than good, be calling many part of the script way to often. 
	/*$('textarea').live('keyup', function() {
		object = $(this).parents('li');
		if (textAreaKeyUpSyncTimer) clearTimeout(textAreaKeyUpSyncTimer);
		saveLocalNotes(); // Saving notes whenever there can be a change to the notes. 
		textAreaKeyUpSyncTimer = setTimeout(function(){
			saveNote(object, false);
			textAreaKeyUpSyncTimer = false;
		},200);
	});*/
	// An alternative way to save, ctrl + click does also work. 
	// + making enter work in login and createuser, hardcore style. (I cant use a normal form.)
	// First i made these bindings in "native" javascript. But changed to jQuery, because it was not reliable. 
	var isCtrl = false;
	$(document).keyup(function(e) {
		if(e.which == 17) isCtrl = false;
	});
	// A little fix to make it work. 
	$(window).blur(function () {
		isCtrl = false;
	});
	$(document).keydown(function(e) {
		if(e.which == 17) isCtrl=false;
		if(e.which == 17) isCtrl=true;
		if(e.which == 83 && isCtrl == true) 
		{
			var focusTextarea = $('textarea:focus');
			if (focusTextarea.length)
			{
				focusTextarea.parents('li').find('.save').click();	
			}
			return false;
		}
		if (e.which == 13)
		{
			// The user pressed enter, lets see if that means anything. 	
			if ($('.ui-page-active').attr('data-role') == 'dialog')
			{
				// They are in the log in or create user dialog. 
				$('.ui-page-active').find('.createUser, .login').click();
			}
			else
			{	
				// They want to "enter" a note. 
				var org = $('.ui-btn-hover-c');
				// But time to find out if its a enter meant for a textarea input. 
				var textarea = $('textarea:focus');
				var textareaProblem = false;
				if (textarea.length)
				{
					if (!textarea.parent().parent().find('h3').hasClass('ui-collapsible-heading-collapsed'))
					{
						textareaProblem = true;	
					}
				}
				
				if (org.length && !textareaProblem)
				{
					if (org.find('.add-new-note').length)
					{
						$('.add-new-note').click();
					}
					else
					{
						org.eq(0).click();
					}
					return false;
				}
			}
		}
		if (e.which == 40 || e.which == 38)
		{
			var org = $('.ui-btn-hover-c');
			if (org.find('.add-new-note').length)
			{
				var target = org[e.which == 40 ? 'next' : 'prev']().find('a');
			}
			else
			{
				var target = org.parents('li')[e.which == 40 ? 'next' : 'prev']().find('a');
			}
			if (target.length)
			{
				org.removeClass('ui-btn-hover-c').addClass('ui-btn-up-c');
				target = target.hasClass('add-new-note') ? target.eq(0).parents('li') : target.eq(0);
				target.removeClass('ui-btn-up-c').addClass('ui-btn-hover-c');
			}
		}
	});
	// Doing something jQuery mobile should, but doesn't. 
	$('li').mouseenter(function(){
		 $('.ui-btn-hover-c').removeClass('ui-btn-hover-c').addClass('ui-btn-up-c');
		 $(this).find('h3 a').addClass('ui-btn-hover-c').removeClass('ui-btn-up-c'); // This one should happen automaticly, but i still have it.
	});
	
	$('.delete').live('click', function() {
		// Lets find the id. 
		var id = $(this).parents('li').attr('id');
		deleteNote(id);
		// The power of lazy sync, make change now, then the "backend" of the frontend takes care of the sync later. 
		saveLocalNoteSync('deleted', id, false);
	});
	// Not needed. First: jQuery tried to do its thing anyway, and therefore Two: i do no longer have any forms. 
	/*$('form').live('submit', function() {
		// I handle it another way. 
		return false;
	});*/
	$('div').live('pageshow',function(event, ui){
		if ($('input.user', this).length)
		{
			$('input.user', this).focus();
		}
	});
	$('.createUser').live('click', function() {
		// What username did they input.
		var form = $(this).parent().parent().parent();
		var username = form.find('input.user').val();
		var password1 = form.find('input.password').val();
		var password2 = form.find('input.repeatedPassword').val();
		var remember = form.find('input.remember').attr('checked');
		var error = '';
		if (!username)
		{
			error += 'Insert a username. ';
		}
		if (!password1 || !password2)
		{
			error += ' Insert a password. ';
		}
		if (password1 != password2)
		{
			error += ' Make sure the passwords are the same. ';
		}
		if (error)
		{
			form.find('.error-message').children().text(error).parent().slideDown(400);	
		}
		else
		{
			// Hide it, just to confirm that it is correct. 
			form.find('.error-message').slideUp(400);
			// Lets hash the password (my cheap alternative to SSL).
			var shaObj = new jsSHA(password1, "ASCII");
			var password = shaObj.getHash("SHA-512", "HEX");
			$.post("backend.php", { createUser: username, password: password, remember: remember},
			function(data) {
				var error = '';
				if (data == 2)
				{
					error = 'Username taken';
					
				}
				else if (data == 1)
				{
					$.post("backend.php", { login: username, password: password },
					function(data) {
						window.location.href = window.location.href.split('#')[0];
					});
				}
				else
				{
					error = data;
				}
				if (error)
				{
					form.find('.error-message').children().text(error).parent().slideDown(400);		
				}
				
			});
		}
	});
	$('.LogOut').live('click', function() {
		$.post("backend.php", { logout: 'ehhhh, here goes nothing' },
		function(data) {
			if (data == 1)
			{
				$('#logInList').slideDown(400);
				$('#logOutList').slideUp(400);
				loggedIn = false;
				$('.note').slideUp('slow', function() {
					$(this).remove();
				});
			}
			
		});
		return false;
	});
	$('.login').live('click', function() {
		// What username did they input.
		var form = $(this).parent().parent().parent();
		var username = form.find('input.user').val();
		var password = form.find('input.password').val();
		var remember = form.find('input.remember').attr('checked');
		var error = '';
		if (!username)
		{
			error += 'Insert a username. ';
		}
		if (!password)
		{
			error += ' Insert a password. ';
		}
		if (error)
		{
			form.find('.error-message').children().text(error).parent().slideDown(400);	
		}
		else
		{
			// Hide it, just to confirm that it is correct. 
			form.find('.error-message').slideUp(400);
			// Lets hash the password (my cheap alternative to SSL).
			var shaObj = new jsSHA(password, "ASCII");
			var password = shaObj.getHash("SHA-512", "HEX");
			$.post("backend.php", { login: username, password: password, remember: remember },
			function(data) {
				error = '';
				if (data == 1)
				{
					window.location.href = window.location.href.split('#')[0];
				}
				else if (data == 3)
				{
					error += 'Wrong user name or password';
				}
				else
				{
					error += data;
				}
				if (error)
				{
					form.find('.error-message').children().text(error).parent().slideDown(400);		
				}
				
			});
		}
		return false;
	});
	// This is just to update the UI. It has NO practical use, and it doesn't change ANYTHING!
	$('textarea').live('keyup', function() {
		fixHeadLine($(this).parents('li').eq(0).find('h3'), $(this).val());
	});
	$('.note').live('click', function () {
		$(this).find('textarea').focus().keyup();
	});
	$('.goOnline').click(function () {
		goOnline();
	});
});
// Finally, the functions. 
// Not so much a fix-headline after upgrade from jQuery mobile 1.0b2 to 1.0rc2
function fixHeadLine(h3, text)
{
	var newHeadLine = text ? text.split(/\n/g)[0] : '';
	h3.find('.ui-btn-text').text(newHeadLine);
	h3.parents('li').eq(0).find('.ui-icon-minus, .ui-icon-plus').css('margin-top', '-10px'); // Ugly fix, but it works. DONT ask me why. 
}
function insertNote (guid, noteText, collapsed, delay)
{
	var li = $('li#' + guid);
	if (li.length)
	{
		var li = $('li#' + guid);
		li.find('textarea').val(noteText);
		fixHeadLine(li.find('h3'), noteText);
	}
	else
	{
		var newNoteObject = $('<li id="' + guid + '" class="note"> <div data-role="collapsible"  data-collapsed="' + collapsed + '" style="postion:relative;"> <h3>' + (noteText ? noteText.split(/\n/g)[0] : '')+ '</h3> <textarea style="width:100%;padding-left:8px;">' + noteText + '</textarea><div data-role="controlgroup" data-type="horizontal" > <a class="save" data-role="button" data-icon="check">Save</a> <a class="delete" data-role="button" data-icon="delete">Delete</a>  </div> </div> </li>');
		$('#notes').children().eq(0).after(newNoteObject);	
		newNoteObject.trigger('create');
		if (delay)
		{
			newNoteObject.slideUp(0).slideDown(300, function () {
				$(this).find('textarea').focus();
			});
		}
		else
		{
			newNoteObject.find('textarea').focus();
		}
	}
}
function deleteNote(id)
{
	li = $('li#' + id);
	if ($('li#' + id).length)
	{
		if (li.attr('deleted') != 'true')
		{
			li.attr('deleted', 'true')
			// Focusing on the next element. If the deleted element has focus. 
			if ($('textarea:focus').parents('li').attr('id') == id)
			{
				li.next().find('a').eq(0).removeClass('ui-btn-up-c').addClass('ui-btn-hover-c');
			}
			li.slideUp(300, function () {
				$(this).remove();
				saveLocalNotes();
			});
			localStorage.removeItem("notes_note_" + id);
		}
	}
}
function saveNote(li, closeNote)
{
	// Lets find the id. 
	var id = li.attr('id');
	var text = li.find('textarea').val();
	pushSyncNoteID = id;
	if (pushSyncNoteTimeout) clearTimeout(pushSyncNoteTimeout);
	pushSyncNoteTimeout = setTimeout(function(){
		pushSyncNoteID = false;
	},2000);
	saveLocalNoteSync('saved', id, false);
	if (closeNote) li.children().children().click();
	// Loving lazy sync. 
}
function saveLocalNoteSync(action, id, remove)
{
	
	if (action != 'saved' || id.slice(0,15) != 'TemperaryNoteId')
	{
		// Valid values of action: 'added', 'saved' and 'deleted'. 
		var syncPlace = "notes_sync_" + action;
		var array = localStorage[syncPlace] ? localStorage[syncPlace].split(',') : new Array();
		if (remove)
		{
			if (jQuery.inArray(id, array) > -1) // Do not want to waste the efford if is isn't there. 
			{
				// Now we actually care about delting it.
				array.splice(jQuery.inArray(id, array), 1);
				localStorage[syncPlace] = array.join(',');
			}
		}
		else
		{
			if (jQuery.inArray(id, array) == -1) // Do not want to waste the efford if its already there. 
			{
				// Now we actually care about saving the sync. 
				array.push(id);
				localStorage[syncPlace] = array.join(',');
				// If theres something to do, it will be done. 
				$(document).trigger('NoteAppSyncEvent');
			}
		}
	}
}
// The function that sends the unsend changes to the server. This is where i have to be creative. 
function sendLocalNoteSync (callback)
{
	// I start with the notes that have been deleted. 
	var deleted = localStorage["notes_sync_deleted"];
	var added = localStorage["notes_sync_added"];
	var saved = localStorage["notes_sync_saved"];
	if (deleted)
	{
		deleted = deleted.split(',');
		deletedNote = deleted[0];
		if (deletedNote)
		{
			$.ajax({
				type: 'POST',
				url: "backend.php",
				data: { deleteNote: deletedNote},
				error: function() {
					goOffline(false);
				},
				success: function(data) {
					$('#dropDownNotifications').children().text('Syncing changes to server');
					if (data != 1)
					{
						alert("I couldn't delete the note, because the server says that you are not logged in. (Or maybe some kind of error happened, the server response is in the next alert)");	
						alert(data);
					}
					else
					{
						saveLocalNoteSync('deleted', deletedNote, true);
						
						// Lets also make sure that i do not try to add or save it in a second. 
						// In the list of notes to save. 
						var changeSavedNote = localStorage['notes_sync_saved'];
						if (changeSavedNote)
						{
							changeSavedNote = changeSavedNote.split(',');
							var indexOfNote = jQuery.inArray(deletedNote, changeSavedNote);
							if (indexOfNote > -1) // Do not want to waste the efford if is isn't there. 
							{
								// Lets remove that entry. 
								changeSavedNote.splice(indexOfNote, 1);
								localStorage['notes_sync_saved'] = changeSavedNote.join(',');
							}

						}
					}
					// Recursive functions!
					sendLocalNoteSync(callback);
				}
			});	
		}
		else
		{
			localStorage["notes_sync_deleted"] = localStorage["notes_sync_deleted"].slice(1,localStorage["notes_sync_deleted"].length);
			sendLocalNoteSync(callback);	
		}
	}
	else if (added)
	{
		added = added.split(',');
		addedNote = added[0]
		if (addedNote)
		{
			$.ajax({
				type: 'POST',
				url: "backend.php",
				data: { newNote: 'Nothing here'},
				error: function() {
					goOffline(false);
				},
				success: function(data) {
					$('#dropDownNotifications').children().text('Syncing changes to server');
					if (data.slice(0,1) == '1')//TemperaryNoteId
					{
						var id = data.slice(1, data.length);
						// Lets change it in the local notes. 
						var textValue = localStorage["notes_note_" + addedNote];
						// Put it into the new localStorage
						localStorage["notes_note_" + id] = textValue;
						// Removing the old one. 
						localStorage.removeItem("notes_note_" + addedNote)	
						
						// Time to change every possible reference of the temperary ID. 
						// First the note itself in the html. 
						$('li#' + addedNote).attr('id', id);
						
						// Lets make sure that its saved. 
						saveLocalNoteSync('saved', id, false);
						
						// I also need to modify the local idlist. 
						// First remove the old one. 
						var idList = localStorage['notes_idList'];
						if (idList)
						{
							idList = idList.split(',');
							var indexOfNote = jQuery.inArray(addedNote, idList);
							if (indexOfNote > -1) // Do not want to waste the efford if is isn't there. 
							{
								// Lets remove that entry. 
								idList.splice(indexOfNote, 1);
								localStorage['notes_idList'] = idList.join(',');
							}

						}
						// And add the new one. 
						localStorage["notes_idList"] = localStorage["notes_idList"] + id + ',';
						
						// Then i also need to delete the reference that brought us here in the first place. 
						saveLocalNoteSync('added', addedNote, true);
					}
					else
					{
						alert('I tried to save, but for some odd reason you weren\'t logged in. Plz send me a mail if you didn\'t try to hack into my system.');
						alert(data);
					}
					// Recursive functions!
					sendLocalNoteSync(callback);
				}
			});
		}
		else
		{
			localStorage["notes_sync_added"] = localStorage["notes_sync_added"].slice(1,localStorage["notes_sync_added"].length); // Deleting the commna that is troubleing. 
			sendLocalNoteSync(callback);	
		}
	}
	else if (saved)
	{
		saved = saved.split(','); //høns
		savedNote = saved[0];
		noteText =  localStorage["notes_note_" + savedNote];
		if (noteText == undefined)
		{
			noteText = $('li#' + savedNote).find('textarea').val();
		}
		if (savedNote)
		{
			$.ajax({
				type: 'POST',
				url: "backend.php",
				data: { save: savedNote, content: noteText},
				error: function() {
					goOffline(false);
				},
				success: function(data) {
					$('#dropDownNotifications').children().text('Syncing changes to server');
					if (data == 1)
					{
						saveLocalNoteSync('saved', savedNote, true);
					}
					else
					{
						alert("I couldn't save, because the server says that you are not logged in. (Or maybe some kind of error happened, the server response is in the next alert)");	
						alert(data);
					}
					// Recursive functions!
					sendLocalNoteSync(callback);
				}
			});			
		}
		else
		{
			localStorage["notes_sync_saved"] = localStorage["notes_sync_saved"].slice(1,localStorage["notes_sync_saved"].length); // Deleting the commna that is troubleing. 
			sendLocalNoteSync(callback);	
		}
	}
	// Nothing left to do. 
	else
	{
		if (online)
		{
			$(document).bind('NoteAppSyncEvent', function() {
				$(document).unbind('NoteAppSyncEvent');
				sendLocalNoteSync();
			});
		}
		if (callback) callback();	
	}
	// The ones that need to be saved aren't saved here, thats done when i load the whole thing in the init function. 
}
function goOffline(init)
{
	$('#dropDownNotifications')
		.children().text('Couldn\'t connect to server, going offline')
		.parent().slideDown(400, function ()
		{
			setTimeout(function(){
				$('#dropDownNotifications').slideUp(400);
			},5000);	
		});
	$(document).unbind('NoteAppSyncEvent');
	online = false;
	$('#logInList').slideUp(400);
	$('#logOutList').slideUp(400);
	$('#offLineControls').slideDown(400);
	if (init)
	{
		$('.note').remove();
		loadLocalNotes();
	}
	// $('textarea').prop("disabled", true); // Uncomment for read-only offline mode. 
}
function goOnline()
{
	$('#dropDownNotifications')
	.children().text('Trying to go online.')
	.parent().slideDown(400);
	$(document).unbind('NoteAppSyncEvent');
	sendLocalNoteSync(function ()
	{
		$('#dropDownNotifications')
			.children().text('You are now back online.')
			.parent().slideDown(400, function ()
			{
				setTimeout(function(){
					$('#dropDownNotifications').slideUp(400);
				},2000);	
			});
		online = true;
		$('#dropDownNotifications').slideUp(400);
		$('#logInList').slideDown(400);
		$('#logOutList').slideUp(400);
		$('#offLineControls').slideUp(400);
		// $('textarea').prop("disabled", false); // Uncomment for read-only offline mode. 
		// Lets restart the damn thing. 
		initTodoApp(true);
	});
}
// I work with 2 sets of local informations. 
// 1. set containing a copy of how everything looks. 
// and 1. set containing all the unsynced changes, split into 3 categories (added, saved and deleted). 
// The set containing all the changes does not contain any informtion about the notes, except a ID. I can always get the actual note somewhere else. (in the html, in localstorage and on the server)
function saveLocalNotes()
{
	// alert("caller is " + arguments.callee.caller.toString());
	var oldList = localStorage["notes_idList"];
	localStorage["notes_idList"] = '';
	$('.note').reverse(/*To make it show up in the right order*/).each(function(){
		id = $(this).attr('id');
		localStorage["notes_idList"] += id + ',';
		localStorage["notes_note_" + id] = $(this).find('textarea').val();
	});
	// Cleaning up. 
	// Not using at the moment, because it DOESN'T WORK!.
	/*var deletedNotes = getNonExistantLocals(localStorage["notes_idList"].split(','), oldList.split(','));
	
	for (a in deletedNotes)
	{
		if (deletedNotes[a])
		{
			localStorage.removeItem("notes_note_" + deletedNotes[a])	
		}
	}*/
	
}
function loadLocalNotes()
{
	var idList = localStorage["notes_idList"];
	if (idList)
	{
		var ids = idList.split(',');
		for (id in ids)
		{
			if (ids[id]) // I got an empty element in the end. 
			{
				if (localStorage["notes_note_" + ids[id]])
				{
					insertNote(ids[id], localStorage["notes_note_" + ids[id]], 'true', false);
				}
			}
		}
	}
}
function initTodoApp(init)
{
	// See if the user has already logged in. 
	$.ajax({
		type: 'POST',
		url: "backend.php",
		data: { Checklogin: 'ehhhh, here goes nothing'},
		error: function() {
			goOffline(true);
		},
		success: function(data) {
			online = true;
			if (data != 3)
			{
				$('#logInList').slideUp(400);
				$('#offLineControls').slideUp(400);
				$('#logOutList').slideDown(400);
				loggedIn = true;
				// Logged in YEAH. Now to add the content. hmm. how to do that. 
				$.ajax({
					type: 'POST',
					url: "backend.php",
					data: { get: 'content'},
					dataType: 'json',
					error: function() {
						alert('Another case of this shouldn\'t happen, the script wasn\'t able to get the content from the server. But i was able to get the login status. Going offline. ');
						goOffline(true);
					},
					success: function(data) {
						if (data != '3')
						{
							$.each(data, function(guid, noteText) {
								// First i see if theres a newer local version available
									// Valid values of action: 'added', 'saved' and 'deleted'. 
								var syncPlace = "notes_sync_saved";
								var array = localStorage["notes_sync_saved"] ? localStorage["notes_sync_saved"].split(',') : new Array();
								if (jQuery.inArray(guid, array) > -1) // Do not want to waste the efford if is isn't there. 
								{
									// Okay, we got some newer content, lets find it. 
									noteText = localStorage["notes_note_" + guid];
									// And lets remove the reference that this needed to be saved. 
									saveLocalNoteSync('saved', guid, true);
								}
								insertNote(guid, noteText, 'true', !!init);
								
							});
							saveLocalNotes();
						}
						else
						{
							alert('Yet again, i tried to get the users content, but i don\'t know what user, because the user isn\'t logged in.	');
							alert('And that is weird, because the user was logged in a couple of milliseconds ago');
						}
					}
				});
				// Push sync, YEAH 
				// But only after i send the request for the content, dont wanna keep the user (or me) waiting. 
				var pusher = new Pusher('676b265d9c19258d7336');
				var channel = pusher.subscribe(data);
				channel.bind('TODO', function(data) {
					data = jQuery.parseJSON(data);
					$.each(data, function(key, val) {
						var guid = key;
						var noteText = val; 
						var collapsed = 'true';
						if (key == 'delete')
						{
							deleteNote(noteText); // In this case, noteText is the ID. 
						}
						else
						{
							var li = $('textarea:focus').parents('li');
							var focusId = li.attr('id');
							var collapsed = li.find('.ui-collapsible-contain').attr('data-collapsed');
							if (focusId != guid && pushSyncNoteID != guid && collapsed != 'false')
							{
								insertNote(guid, noteText, 'true', true);
							}
							if (pushSyncNoteID == guid)
							{
								pushSyncNoteID = false;
							}
						}
						saveLocalNotes();
					});
				});		
			}
		}
	});
}
// This function finds the elements in the oldList, that are not present in the newList.
// I could just for each element in the oldlist, search the whole newList. But thats to easy and slow, especially when both lists are sorted in the same order. I just replaced O(n^2) wih O(n), hell yeah!
function getNonExistantLocals(newList, oldList)
{
	// First, i make sure that they are sorted in the same way. 
	// For some weird reson, Firefox and Chrome sorts the opposite when reciving the notes from the server.
	// I sure hope that .sort uses mergesort, or else all this effort would just be a waste. 
	newList = newList.sort(sortNumber);
	oldList = oldList.sort(sortNumber);
	// Now the algorithm. 
	returnArray = new Array();
	a = 0;
	b = 0;
	lastAdd = null;
	while (b < newList.length && a < oldList.length)
	{
		//alert("Server:" + newList[a] + " local:" + oldList[b]);
		if (newList[b] == oldList[a])
		{
			a++;
			b++;	
		}
		else if (oldList[a] < newList[b])
		{
			returnArray.push(oldList[a]);
			a++;
		}
		else
		{
			// I you would like the function to return all uniqe elements, you could add the following commented line:
			// returnArray.push(newList[b]);
			b++;
		}
	}
	if (a < oldList.length )
	{
		for (i = a; i < oldList.length; i++)
		{
			returnArray.push(oldList[i]);
		}
	}
	return returnArray;
}
// Simple function, so i can sort numbers. 
function sortNumber(a,b)
{
	return a - b;
}