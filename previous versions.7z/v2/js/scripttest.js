$(document).ready(function () {
	$('.performtest').click(function () {
		$('#notes-list').animate({
			width: '40%'
		}, 400);
		$('#notes-content').animate({
			width: '60%'
		}, 400);
	});
	$('.save').click(function () {
		$('#notes-content').animate({
			width: '0%'
		}, 400, function () {
			$('#notes-list').animate({
				width: '100%'
			}, 400);	
		});
	});
});
