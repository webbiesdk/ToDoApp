<?php
// Mini docs. 
/*
Home made error codes: 
1 == no errors. 
2 == username already exits. 
3 == wrong username or password
*/

// Connect to the server, no problem. 
$hostname = "localhost";
$username = "webbies_dk";
$password = "ugGj5Fm2";
$dabebase = "webbies_dk";
mysql_connect($hostname, $username, $password) or die(mysql_error());
mysql_select_db($dabebase) or die(mysql_error());
mysql_query("CREATE TABLE IF NOT EXISTS notes(
    id INT AUTO_INCREMENT,
    username TEXT,
    password TEXT,	
	lastsync INT,
	notes LONGTEXT,
    PRIMARY KEY(id)
)") OR DIE(mysql_error());
mysql_query("CREATE TABLE IF NOT EXISTS notes_session(
    id INT AUTO_INCREMENT,
    username TEXT,
    sid TEXT,
	userAgent TEXT,
    PRIMARY KEY(id)
)") OR DIE(mysql_error());

include 'functions.php';


// First i handle the case, where we create a new user. 
if ( $_POST["createUser"] )
{
	$user = $_POST["createUser"];
	$user = mysql_real_escape_string(stripslashes($user));
	$user = mysql_real_escape_string($user);
	$remember = $_POST['remember'];
	// First i check if someone already used that name.
	$result = mysql_query("SELECT * FROM notes WHERE username='$user'") OR DIE(mysql_error());
	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result);
	// There cant be any. 
	if($count==0){
		// We continue
		$password = $_POST["password"]; // The password should already be MD5 hashed at this point. 
		$password = stripslashes($password);
		$password = mysql_real_escape_string($password);
		mysql_query("INSERT INTO notes (username, password, lastsync) VALUES ('$user', '$password', '0')") OR DIE(mysql_error());
		
		// Then we need to log in. 
		login($user, $remember);
		echo '1';// 1 == no errors. 
	}
	else {
		echo "2";// 2 == username already exits. 
	}
}
// If the user tries to log in. 
if ( $_POST["login"] )
{
	// username and password sent from form 
	$user=$_POST['login']; 
	$password = $_POST['password'];
	$remember = $_POST['remember'];
	
	// To protect MySQL injection (more detail about MySQL injection)
	$user = stripslashes($user);
	$user = mysql_real_escape_string($user);
	
	$result =  mysql_query("SELECT password FROM notes WHERE username='$user'") OR DIE(mysql_error());
	while($row = mysql_fetch_assoc($result)) //Lav en while der k�rer alle r�kker igennem
	{
		$MySQLPassWord = $row['password'];
	}
	
	// Mysql_num_row is counting table row
	$count = mysql_num_rows($result);
	// If result matched $user and $password, table row must be 1 row
	
	if($count == 1){
		if ($password == $MySQLPassWord)
		{
			// Remeber it. 
			if (login($user, $remember))
			{
				echo '1';// 1 == no errors. '
			}
			else
			{
				echo '7'; // Plain unkown error, this shouldn't happen. 
			}
		}
		else {
			echo '3';// 3 == wrong username or password. 
		}
	}
	else {
		echo '3';// 3 == wrong username or password. 
	}
}
// I just ask. 
if ( $_POST["Checklogin"] )
{
	if (loginCheck())
	{
		echo '1';	
	}
	else
	{
		echo '3';
	}
}
if ( $_POST["logout"] )
{
	// Simple, effective. 
	$ID = $_COOKIE['ToDoSID'];
	mysql_query("DELETE FROM notes_session WHERE sid='$ID'");
	$pastdate = mktime(0,0,0,1,1,1970);
	setcookie("ToDoSID","",$pastdate, '/', 'webbies.dk');
	echo '1';// 1 == no errors. 
}
//mysql_query("INSERT INTO notes (content, deleted) VALUES ('Anders', 1)") OR DIE(mysql_error());
if ( $_POST["save"] )
{
	$user = loginCheck();
	$content = $_POST["save"];
	$content = str_replace("\\", "", $content);
	$content = mysql_real_escape_string(stripslashes($content));
	if ($user)
	{
		mysql_query("UPDATE notes SET notes = '$content' WHERE username = '$user'") OR DIE(mysql_error());
		
		// We also need to update lastsync number. 
		$query = mysql_query("SELECT lastsync FROM notes WHERE username = '$user'") OR DIE(mysql_error());
		while($row = mysql_fetch_assoc($query)) //Lav en while der k�rer alle r�kker igennem
		{
			$lastsync = $row['lastsync'];
		}
		$lastsync = $lastsync + 1;
		mysql_query("UPDATE notes SET lastsync = '$lastsync' WHERE username = '$user'") OR DIE(mysql_error());
		echo '1';
	}
	else
	{
		echo '3';	
	}
	
}
if ( $_POST["get"] )
{
	if ($_POST["get"] == 'content')
	{
		$user = loginCheck();
		if ($user)
		{
			$query = mysql_query("SELECT * FROM notes WHERE username = '$user'") OR DIE(mysql_error());
			while($row = mysql_fetch_assoc($query)) //Lav en while der k�rer alle r�kker igennem
			{
				echo '1';
				echo $row['notes'];
			}
		}
		else
		{
			echo '3';	
		}
	}
	else if ($_POST["get"] == 'lastsync')
	{
		$user = loginCheck();
		if ($user)
		{
			$query = mysql_query("SELECT * FROM notes WHERE username = '$user'") OR DIE(mysql_error());
			while($row = mysql_fetch_assoc($query)) //Lav en while der k�rer alle r�kker igennem
			{
				echo $row['lastsync'];
			}
		}
		else
		{
			echo 'error'; // Cant use a number here, because any number is a valid output. 
		}
	}
	else
	{
		echo '4';	
	}
}

?>